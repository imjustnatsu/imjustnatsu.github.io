CREATE TABLE fim_rules (
    fim_rule_id integer not null primary key,
    fim_rule_name varchar(60) not null,
    path varchar(50) not null,
    start_inode integer,
    inode boolean,
    parent boolean,
    name boolean,
    type boolean,
    mode boolean,
    nlink boolean,
    uid boolean,
    gid boolean,
    size boolean,
    atime boolean,
    mtime boolean,
    md8 boolean,
    sha1 boolean);


CREATE TABLE stat_files (
    file_inode integer not null primary key,
    parent_id integer not null,
    file_name varchar(60) not null,
    file_type text not null,
    file_mode varchar(60),
    file_nlink integer,
    file_uid integer,
    file_gid integer,
    file_size integer,
    file_atime timestamp,
    file_mtime timestamp,
    file_ctime timestamp,
    file_md5 varchar(60),
    file_SHA1 varchar(60));

create table ref_images (
	image_id integer primary key,
	file_inode integer,
	datetime_image timestamp,
	parent_id integer,
	file_name varchar(60),
	file_type text,
	file_mode varchar(60),
	file_nlink integer,
	file_uid integer,
	file_gid integer,
	file_size integer,
	file_atime timestamp,
	file_mtime timestamp,
	file_ctime timestamp,
	file_md5 varchar(60),
	file_SHA1 varchar);

CREATE TABLE fim_sets (
    fim_set_id integer not null primary key,
    fim_rule_id integer not null,
    fim_set_name varchar(60),
    schedule integer,
    foreign key(fim_rule_id) references fim_rules(fim_rule_id));

CREATE TABLE fim_events (
    fim_event_id integer not null primary key,
    fim_rule_id integer not null,
    image_id integer not null,
    file_inode integer not null,
    datetime_event timestamp not null ,
    except_msg varchar(60),
    except_active boolean,
    foreign key(fim_rule_id) references fim_rules(fim_rule_id),
    foreign key(image_id) references ref_images(image_id),
    foreign key(file_inode) references stat_files(file_inode));

CREATE TABLE sa_jobs (
    sa_job_id integer not null primary key,
    sa_job_name varchar(60) not null,
    script boolean not null,
    command_script varchar(60),
    expected_result varchar(60),
    alert_message varchar(60));


CREATE TABLE sa_events (
    sa_event_id integer not null primary key,
    sa_job_id integer not null,
    datetime_Event timestamp not null ,
    except_active boolean,
    foreign key(sa_job_id) references sa_jobs(sa_job_id));