import socket
import ipaddress
import zlib


def server():
    size = 2048
    s = socket.socket(family=socket.AF_INET, type=socket.SOCK_STREAM)
    s.bind(("0.0.0.0", 8880))
    s.listen(0)


    while True:
        conn, (ip, port) = s.accept()
        print(f"Connected to {ipaddress.IPv4Address(ip)}:{port}")
        while True:
            data = conn.recv(size)
            verif = zlib.crc32(data)
            if not data:
                break
            print(f"[+] Server Received : {bytes.decode(data)} : Crc {verif}")
            msg = str.encode(f"[+] Server : Send message received :")
            conn.send(msg)
        conn.close()
while True:
    server()