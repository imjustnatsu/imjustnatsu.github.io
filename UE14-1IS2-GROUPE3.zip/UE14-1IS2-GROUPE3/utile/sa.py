import subprocess
import data
import time

#chemin vers la base de donnée
db_filename = '/home/student/PycharmProjects/UE14-1IS2-GROUPE3/cli_panoptes/data/cli_panoptes.sqlite'
#delet = 'DELETE FROM sa_events WHERE sa_event_id> 0;'

def sa_verif():
    """
    Permet de vérifier l'état d'un fichier.
    :return: Stock dans la base de donnée les erreurs.
    """
    sql = 'INSERT INTO sa_events(sa_job_id, datetime_Event, except_active) VALUES(?,?,?)'
    for i in range(1,3):
        i = str(i)
        #on selectionne les valeurs dans sa_jobs
        val = data.select_all_tasks("SELECT * FROM sa_jobs WHERE sa_job_id = "+i+"")
        #on effectue la commande de la base de donnée
        res = subprocess.run(["/bin/sh","-c",f'{val[3]}'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        etat = res.stdout.decode("utf-8")
        etat = etat.split()
        vall = val[4]
        vall = vall.split()
        if etat[0] == vall[0]:
            pass
        else:
            #si ce n'est pas la valeur attendu on l'ajoute dans la base de donnée
            sa_job_id = val[0]
            datetime_job = int(time.time())
            #i = int(i)
            task = (sa_job_id,datetime_job,1)
            data.create_task(sql,task)
