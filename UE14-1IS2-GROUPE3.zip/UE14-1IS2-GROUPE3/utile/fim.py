import os
from pathlib import Path
import time
import hashlib
import ntpath
import data

timestamp = int(time.time())


def stat():
    """
    Permet de créer une image du dossier choisis
    :return: image du dossier (return en dictionnaire)
    """
    root = Path('/home/student/docker-dvwa/')
    dicotest, id_n = {}, 1
    # Parcourir l'ensemble des fichiers du dossier choisis comme root
    for i in root.rglob("*"):
        # Vérification si l'élément est un fichier ou un dossier
        if i.is_dir():
            file_type, file_md5, file_sha1 = 'Dossier', 0, 0
        else:
            file_type = 'Fichier'
            #  Lecture du Fichier et chiffrement de son contenu
            with open(i, 'rb') as f:
                content = f.read()
                file_md5, file_sha1 = hashlib.md5(content).hexdigest(), hashlib.sha1(content).hexdigest()
        # Récolte des valeurs pour la base de donnée
        datetime_image = int(time.time())
        file_name = i
        val = os.stat(file_name)
        file_mode = val[0]
        file_inode = val[1]
        file_nlink = val[3]
        file_uid = val[4]
        file_gid = val[5]
        file_size = val[6]
        file_atime = val[7]
        file_mtime = val[8]
        file_ctime = val[9]
        file_name = ntpath.basename(i)
        image_id = id_n
        stat_parent = os.stat(i.parent)
        parent_id = stat_parent.st_ino
        # Insertion des valeurs dans un dictionnaire
        dico = {'image_id': image_id, 'file_inode': file_inode, 'datetime_image': datetime_image,
                'parent_id': parent_id,
                'file_name': file_name, 'file_type': file_type, 'file_mode': file_mode, 'file_nlink': file_nlink,
                'file_uid': file_uid, 'file_gid': file_gid, 'file_size': file_size, 'file_atime': file_atime,
                'file_mtime': file_mtime, 'file_ctime': file_ctime, 'file_md5': file_md5, 'file_sha1': file_sha1}
        # Insertion du dictionnaire dans la liste des dictionnaires
        dicotest[id_n] = dico
        id_n += 1
    return dicotest


def bd_insert(dictionnaire, type):
    """
    Permet d'inserer dans la base de données les images effectué
    :param dictionnaire: valeurs de l'image obtenu dans la fonction stat
    :param type: si c'est l'image de référence ou le stat files que l'on veut
    :return: insert dans la base de données ( stats_files ou ref_images ) les valeurss
    """
    sql, task = "", ""
    # emplacement de la base de données
    db_filename = '/home/student/PycharmProjects/UE14-1IS2-GROUPE3/cli_panoptes/data/cli_panoptes.sqlite'
    # choix entre stat_files et ref_images
    if type == 'event':
        sql = 'INSERT INTO stat_files(file_inode, parent_id, file_name, file_type, file_mode, file_nlink, file_uid, file_gid, file_size, file_atime, file_mtime, file_ctime, file_md5, file_SHA1) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
    elif type == 'ref':
        sql = 'INSERT INTO ref_images(image_id, file_inode, datetime_image, parent_id, file_name, file_type, file_mode, file_nlink, file_uid, file_gid, file_size, file_atime, file_mtime, file_ctime, file_md5, file_SHA1) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
    # insertion dans la base de données de chaque éléments du dictionnaire
    for y in dictionnaire.values():
        if type == 'event':
            task = (y['file_inode'], y['parent_id'], y['file_name'], y['file_type'], y['file_mode'], y['file_nlink'],
                    y['file_uid'], y['file_gid'], y['file_size'], y['file_atime'], y['file_mtime'], y['file_ctime'],
                    y['file_md5'], y['file_sha1'])
        elif type == 'ref':
            task = (y['image_id'], y['file_inode'], y['datetime_image'], y['parent_id'], y['file_name'], y['file_type'],
                    y['file_mode'], y['file_nlink'], y['file_uid'], y['file_gid'], y['file_size'], y['file_atime'],
                    y['file_mtime'], y['file_ctime'], y['file_md5'], y['file_sha1'])
        data.create_task(sql, task)
    data.deconnexion(db_filename)


def verif():
    """
    Vérifie si les valerus de la base de donnée a été modifié
    :return: stock dans fim_events les érreurs obtenus
    """
    sql = "INSERT INTO fim_events(fim_rule_id, image_id, file_inode, datetime_event, except_msg, except_active) VALUES (?,?,?,?,?,?)"
    # permet d'avoir le nom des colonnes
    select_column = data.column_names('stat_files')
    # permet d'avoir le nombre d'éléments a analyser
    dernier = data.select_all_tasks("SELECT * FROM ref_images")
    valeur_max = int(dernier[0])
    # execution sur l'ensemble des valeurs grace à l'id et l'inode
    for id_incr in range(1, valeur_max + 1):
        # on prend les valeur de ref_images et stats_files
        ref = data.select_all_tasks(f"SELECT * FROM ref_images WHERE image_id = {id_incr}")
        stat = data.select_all_tasks(f"SELECT * from stat_files WHERE file_inode = {ref[1]}")
        ref = list(ref)
        id_ima = ref[0]
        # on enleve image_id et datetime_image de ref_images pour qu'ils soient égaux
        ref.pop(2) and ref.pop(0)
        id_colonne = 0
        # verifie si l'inode est la même
        if ref[0] == stat[0]:
            # on verifie si chaque valeur est égal
            for x, z in zip(ref, stat):
                # si ce n'est pas égal on le stock dans la base de donnée
                if x != z:
                    erreur = f'Inode = {ref[0]} | {select_column[id_colonne]} | {x} et {z} ne sont pas égaux'
                    task = (1, id_ima, ref[0], timestamp, erreur, 1)
                    data.create_task(sql, task)
                else:
                    pass
                id_colonne += 1
        else:
            pass


def fim_events():
    """
    Permet de vérifier si les valeurs de stats_files et ref_images n'ont pas été altéré
    :return: execute la verification de stats_files et ref_images
    """
    # on vide stats_files
    data.delete_task('DELETE FROM stat_files WHERE file_inode> 0;')
    # on crée une image dans stats_files
    bd_insert(stat(), 'event')
    # on effectue la verification
    verif()
