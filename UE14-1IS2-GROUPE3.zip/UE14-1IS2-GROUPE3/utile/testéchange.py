import socket
import zlib

size = 4096

s = socket.socket(family=socket.AF_INET, type=socket.SOCK_STREAM)
s.connect(("localhost", 8880))

#mmsg = input("Message à envoyer ? ")
mmsg = 'hugo cr ? xD'
msg = str.encode(mmsg)
msg2 = msg.decode()
len_msg = len(msg)
byte_msg = len_msg.to_bytes(4, byteorder='big')
verif = zlib.crc32(msg)

s.send(msg)
data = s.recv(size)

s.close()
print(f"[+] Size:{byte_msg} / Message:{msg.decode()} / Crc:{verif}")

