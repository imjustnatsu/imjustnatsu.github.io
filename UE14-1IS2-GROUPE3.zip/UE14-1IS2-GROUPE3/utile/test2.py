from network2 import *

HOST = 'localhost'
PORT = 8880
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.connect((HOST, PORT))
    message = 'sup babygirl'
    send_message(s, message)
    data = recv_message(s)
    print(data)