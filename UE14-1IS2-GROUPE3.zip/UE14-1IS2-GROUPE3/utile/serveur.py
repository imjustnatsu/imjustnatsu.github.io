import socket
import threading

def client_thread(client_socket: socket.socket):
    request = client_socket.recv(4096)
    client_socket.send(request)
    client_socket.close()

def launch_server():
    server_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR, 1)
    server_socket.bind(("127.0.0.1", 8880))
    server_socket.listen(0)
    size = 2048
    while True:
        conn,(client_socket, address) =server_socket.accept()
        print(f"[+] Received connexion from : {address}")
        ct = threading.Thread(target=client_thread,args=(client_socket,))
        ct.run()

        data = conn.recv(size)
        if not data:
            break
        print(f"[+] Server Received : {data.decode()}")
        msg = str.encode("[+] Server : Send message received")
        conn.send(msg)
    conn.close()


launch_server()
