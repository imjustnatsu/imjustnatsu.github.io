import socket
import ipaddress
import zlib
import threading


def client_thread(client_socket: socket.socket):
    request = client_socket.recv(4096)
    print(request)
    client_socket.send(request)


def server():
    size = 2048
    server_socket = socket.socket(family=socket.AF_INET, type=socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server_address = ('localhost', 8880)
    server_socket.bind(server_address)
    server_socket.listen(0)
    while True:
        print("Waiting for connection")
        conn, (ip, port) = server_socket.accept()
        print(f"Connected to {ipaddress.IPv4Address(ip)}:{port}")
        #client_thread(socket.socket)
        while True:
            data = conn.recv(size)
            verif = zlib.crc32(data)
            if not data:
                break
            print(f"[+] Server Received : {bytes.decode(data)} : Crc {verif}")
            msg = str.encode(f"[+] Server : Send message received :")
            conn.send(msg)
        conn.close()
while True:
    server()