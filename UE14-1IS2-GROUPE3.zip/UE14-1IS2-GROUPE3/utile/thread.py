import queue
import threading
from threading import Thread, Lock
import time
import fim
import sa


sql = 'DELETE FROM ref_images WHERE image_id > 0;'
db_filename = '/home/student/PycharmProjects/UE14-1IS2-GROUPE3/cli_panoptes/data/cli_panoptes.sqlite'
lock = threading.Lock()


def thread_fim(exception_queue):
    global lock

    for i in range(0, 3):

        with lock:
            time.sleep(1)
            fim.fim_events()
            exception_queue.put({"message": f"[thread-{threading.get_ident()}] exception {1} from FIM"})
    exception_queue.task_done()
    return


def thread_sa(exception_queue):
    global lock

    for i in range(0, 3):
        # acquérir le blocage
        time.sleep(1)
        sa.sa_verif()
        exception_queue.put({"message": f"[thread-{threading.get_ident()}] exception {1} from SA"})
        # Blocage réalisé
    exception_queue.task_done()
    return


q_message_recu = queue.Queue()  # Reception des exceptions

t_fim = Thread(target=thread_fim, args=(q_message_recu,))
t_fim.start()

t_sa = Thread(target=thread_sa, args=(q_message_recu,))
t_sa.start()

while True:
    obj = q_message_recu.get()
    print(obj)


#t_fim.join()
#t_sa.join()
