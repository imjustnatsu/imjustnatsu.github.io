import json
import socket
import threading
import binascii
import data


def send_message(client_socket, message):
    message = str(message)
    size_msg = len(message)
    checksum = binascii.crc32(message.encode('utf-8'))
    client_socket.send(size_msg.to_bytes(4, byteorder="big"))
    client_socket.send(message.encode())
    client_socket.send(checksum.to_bytes(4, byteorder="big"))


def send_message_dict(client_socket, msg):
    message = json.dumps(msg).encode('utf-8')
    size_msg = len(message)
    checksum = binascii.crc32(message)
    client_socket.send(size_msg.to_bytes(4, byteorder="big"))
    client_socket.send(message)
    client_socket.send(checksum.to_bytes(4, byteorder="big"))


def recv_message(client_socket):
    # lis 4 octets, convertis les octets en entier X, lis X bytes depuis le socket, return ce qui est lu

    len_msg_bytes = client_socket.recv(4)
    size_msg = int.from_bytes(len_msg_bytes, byteorder='big')

    msg = client_socket.recv(size_msg).decode()

    checksum = client_socket.recv(4)
    checksum_int = int.from_bytes(checksum, byteorder='big')
    checksum_final = binascii.crc32(msg.encode('utf-8'))

    if checksum_int != checksum_final:
        print(f'Erreur checksum! {checksum_int} != {checksum_final}')

    return msg


def recv_message_dict(client_socket):
    len_msg_bytes = client_socket.recv(4)
    size_msg = int.from_bytes(len_msg_bytes, byteorder='big')
    msg = client_socket.recv(size_msg)

    checksum = client_socket.recv(4)
    checksum_int = int.from_bytes(checksum, byteorder='big')
    checksum_final = binascii.crc32(msg)

    dict_msg = json.loads(msg.decode('utf-8'))

    if checksum_int != checksum_final:
        return f'Erreur checksum! {checksum_int} != {checksum_final}'
    else:
        return dict_msg


def send_config(host_name):
    dic = {'ACTION': "GET_CONFIG", 'SA_JOBS': [], 'FIM_RULES': []}
    db_path = '../srv_panoptes/data/identifier.sqlite'

    get_id_host = data.select_data(db_path, f'SELECT id FROM client where hostname = "{host_name}"')
    id_host = get_id_host[0]

    st_fim_rules = data.select_all_data(db_path,
                                        f'SELECT fim_rule_id FROM storage_fim_rules where client_id = {id_host}')
    st_sa_job = data.select_all_data(db_path, f'SELECT sa_job_id FROM storage_sa_job where client_id = {id_host}')

    for i in st_fim_rules:
        fim_rules = data.select_data(db_path, f'SELECT * FROM fim_rules where fim_rule_id = {i[0]}')
        dic['FIM_RULES'].append(list(fim_rules))

    for j in st_sa_job:
        sa_jobs = data.select_data(db_path, f'SELECT * FROM sa_jobs where sa_job_id = {j[0]}')
        dic['SA_JOBS'].append(list(sa_jobs))

    return dic


def send_event():
    dic = {'ACTION': "EVENT", 'SA_EVENT': [], 'FIM_EVENT': []}

    db_path_client = '../cli_panoptes/data/cli_panoptes.sqlite'

    fim_events = data.select_all_data(db_path_client, f"SELECT fim_event_id from fim_events")
    sa_events = data.select_all_data(db_path_client, f"SELECT sa_event_id from sa_events")

    for i in fim_events:
        fim_event = data.select_data(db_path_client, f"SELECT * from fim_events where fim_event_id = {i[0]}")
        dic['FIM_EVENT'].append(list(fim_event))

    for j in sa_events:
        sa_event = data.select_data(db_path_client, f"SELECT * from sa_events where sa_event_id = {j[0]}")
        dic['SA_EVENT'].append(list(sa_event))
    return dic


def client_thread(client_socket: socket.socket):
    send_message(client_socket, 'SRV-OK')
    recv_mess = recv_message_dict(client_socket)

    if recv_mess['ACTION'] == 'GET_CONFIG':
        hostname = recv_mess['CLI_NAME']
        db_path = '../srv_panoptes/data/identifier.sqlite'

        get_host_name = data.select_data(db_path, f'SELECT hostname FROM client where hostname = "{hostname}"')

        if not get_host_name:
            error = "Client does not exists !"
            send_message(client_socket, error)
        else:
            config = send_config(hostname)
            send_message_dict(client_socket, config)

    elif recv_mess['ACTION'] == 'EVENT':
        fim_events = recv_mess['FIM_EVENT']
        sa_events = recv_mess['SA_EVENT']
        for i in fim_events:
            query = (i[0], i[1], i[2], i[3], i[4], i[5], i[6])
            insert = "INSERT INTO fim_events(fim_event_id, datetime_event, except_msg, except_active, fim_rule_id, image_id, file_inode) VALUES (?,?,?,?,?,?,?)"
            db_path = '../srv_panoptes/data/identifier.sqlite'
            data.insert_data(db_path, query, insert)

        for j in sa_events:
            query = (j[0], j[1], j[2], j[3])
            insert = "INSERT INTO sa_events(sa_event_id, sa_job_id, datetime_event, except_active) VALUES (?,?,?,?)"
            db_path = '../srv_panoptes/data/identifier.sqlite'
            data.insert_data(db_path, query, insert)

    return client_socket.close()


def launch_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    server_address = ('localhost', 8880)
    server_socket.bind(server_address)

    server_socket.listen(0)

    while True:
        (client_socket, address) = server_socket.accept()
        print(f"[+] received connection from {address}")

        cli_thread = threading.Thread(target=client_thread, args=(client_socket,))
        cli_thread.run()


if __name__ == "__main__":
    launch_server()