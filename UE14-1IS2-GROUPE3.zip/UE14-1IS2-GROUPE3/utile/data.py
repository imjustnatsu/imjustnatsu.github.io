import sqlite3

db_filename = '/home/student/PycharmProjects/UE14-1IS2-GROUPE3/cli_panoptes/data/cli_panoptes.sqlite'


def connect_db(db_filename):
    """
    Etablie la connexion à la base de données
    :param db_filename: chemin vers la base de donnée
    :return: renvoie la connexion à la base de donnée
    """
    sqlite_connextion = None
    try:
        sqlite_connextion = sqlite3.connect(db_filename)
    except sqlite3.Error as error:
        print("Failed to connect database ", db_filename, error)
    finally:
        if sqlite_connextion:
            return sqlite_connextion


def deconnexion(db_filename):
    con = sqlite3.connect(db_filename)
    con.close()


def select_all_tasks(sql):
    """
    Query all rows in the tasks table
    :param conn: the Connection object
    :return:
    """
    row = ''
    conn = connect_db(db_filename)
    cur = conn.cursor()
    # "SELECT * FROM fim_sets"
    cur.execute(sql)
    rows = cur.fetchall()
    for row in rows:
        row = row
    return row


def create_task(sql, task):
    #colonne = column_names(table)
    #valeur = commande(colonne)
    #sql = f'INSERT INTO {table}({colonne}) VALUES({valeur})'
    """
    Create a new task
    :param conn:
    :param task:
    :return:
    """
    conn = connect_db(db_filename)
    cur = conn.cursor()
    cur.execute(sql, task)
    conn.commit()

    return cur.lastrowid


def update_task(sql,task):
    """
    update priority, begin_date, and end date of a task
    :param conn:
    :param task:
    :return: project id
    """
    conn = connect_db(db_filename)
    task = (1255, 155554554, 'sqdcx', 12)
    #sql = '''UPDATE fim_sets
     #         SET fim_set_id = ? ,
      #            fim_rule_id = ? ,
      #            fim_set_name = ?
      #        WHERE schedule = ?'''
    cur = conn.cursor()
    cur.execute(sql, task)
    conn.commit()


def delete_task(sql):
    """
    update priority, begin_date, and end date of a task
    :param conn:
    :param task:
    :return: project id
    """
    conn = connect_db(db_filename)
    cur = conn.cursor()
    cur.execute(sql)
    conn.commit()


def column_names(table):
    try:
        conn = sqlite3.connect(db_filename)
        query = f'select * from {table}'
        cursor = conn.execute(query)
        liste = (list(map(lambda x: x[0], cursor.description)))
        return liste
    except sqlite3.Error as error:
        print('Failed to collect column names!', error)


def count_data_db(table):
    conn = sqlite3.connect(db_filename)
    c = conn.cursor()
    try:
        query = f"SELECT count(*) from {table}"
        c.execute(query)
        nbrows = c.fetchone()[0]
        conn.commit()
        conn.close()
        return nbrows
    except sqlite3.Error as error:
        print('Failed to select data!', error)

