import socket
import threading


def send_message(client_socket, message):
    message = str(message)
    size_msg = len(message)
    client_socket.send(size_msg.to_bytes(4, byteorder="big"))
    client_socket.send(message.encode())


def recv_message(client_socket):
    # lis 4 octets, convertis les octets en entier X, lis X bytes depuis le socket, return ce qui est lu
    len_msg_bytes = client_socket.recv(4)
    size_msg = int.from_bytes(len_msg_bytes, byteorder='big')
    msg = client_socket.recv(size_msg).decode()
    return msg


def client_thread(client_socket: socket.socket):
    request = client_socket.recv(4096)
    print(request)
    print(request)
    send_message(client_socket, recv_message(client_socket))
    print(recv_message(client_socket))
    client_socket.send(request)


def launch_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    server_address = ('localhost', 8880)

    server_socket.bind(server_address)

    server_socket.listen(0)

    while True:
        print("Waiting for connection")
        (client_socket, address) = server_socket.accept()
        print(f"[+] received connection from {address}")
        cli_thread = threading.Thread(target=client_thread, args=(client_socket,))
        cli_thread.run()


if __name__ == "__main__":
    launch_server()